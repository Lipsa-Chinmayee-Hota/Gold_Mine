export class Product{
    pid:number = 0;
    Productname:string|undefined;
    Price:number = 0;
    Availability:boolean = false;
    ImageUrl:string|undefined;
    Weight : number = 0;
    descriptionkey : string| undefined;
}