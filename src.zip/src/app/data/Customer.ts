export class Customer{
    customername:string|undefined;
    emailid:string|undefined;
    mobileno:string|undefined;
    password:string|undefined;
}